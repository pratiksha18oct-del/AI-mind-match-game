# MindMatch — Memory Game and Chaining Demo

A small learning project combining a browser memory game with a Python demonstration of **forward chaining** and **backward chaining**.

## Files
- `index.html` — game page and concept guide
- `style.css` — responsive styling
- `app.js` — card shuffle/matching, move counter, timer, and restart logic
- `python/chaining_demo.py` — rule engine that prints both reasoning paths

## Play
Open `index.html` in a modern browser. No installation or server is required.

## Run the Python demo
From this folder, run:

```bash
python python/chaining_demo.py
```

Python 3.10 or newer is recommended. The script uses only Python's standard library.

## Chaining in this project
The demo uses facts such as `eight_pairs_matched` and rules such as “if all eight pairs are matched, the game is complete.” Forward chaining starts from facts and fires rules to find conclusions. Backward chaining starts with a goal like `game_complete` and checks which facts would prove it.

The website runs in the browser; the Python file is a separate runnable illustration of the AI concept.
