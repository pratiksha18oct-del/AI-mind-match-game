"""Rule-based reasoning demo for the MindMatch memory game.
Run from the project folder: python python/chaining_demo.py
"""
from dataclasses import dataclass

@dataclass(frozen=True)
class Rule:
    name: str
    needs: frozenset[str]
    concludes: str
    explanation: str

RULES = [
    Rule("all_pairs_found", frozenset({"eight_pairs_matched"}), "game_complete", "If all eight pairs are matched, the game is complete."),
    Rule("some_pairs_found", frozenset({"at_least_one_pair_matched"}), "game_in_progress", "If at least one pair is matched, the game is in progress."),
    Rule("no_pairs_yet", frozenset({"zero_pairs_matched"}), "game_started", "A player can start playing before finding a pair."),
]

def forward_chain(facts: set[str], rules: list[Rule]) -> set[str]:
    """Start with known facts and repeatedly fire matching rules."""
    known = set(facts)
    print("Starting facts:", ", ".join(sorted(known)))
    changed = True
    while changed:
        changed = False
        for rule in rules:
            if rule.needs <= known and rule.concludes not in known:
                known.add(rule.concludes)
                changed = True
                print(f"  FIRE {rule.name}: {rule.explanation}")
                print(f"  NEW FACT: {rule.concludes}")
    return known

def backward_chain(goal: str, facts: set[str], rules: list[Rule], seen: set[str] | None = None) -> bool:
    """Start with a goal, then recursively try to prove its requirements."""
    if goal in facts:
        print(f"  PROVED {goal}: it is already a known fact.")
        return True
    if seen is None:
        seen = set()
    if goal in seen:
        return False
    seen.add(goal)
    candidates = [rule for rule in rules if rule.concludes == goal]
    if not candidates:
        print(f"  CANNOT PROVE {goal}: no fact or rule supports it.")
        return False
    for rule in candidates:
        print(f"  CHECK {goal} using {rule.name}: {rule.explanation}")
        if all(backward_chain(premise, facts, rules, seen.copy()) for premise in rule.needs):
            print(f"  PROVED {goal} using {rule.name}.")
            return True
    print(f"  CANNOT PROVE {goal}: its rule requirements are not all known.")
    return False

def main() -> None:
    print("MINDMATCH — FORWARD CHAINING\n" + "=" * 34)
    final_facts = forward_chain({"eight_pairs_matched"}, RULES)
    print("\nConclusion:", "game_complete" in final_facts)
    print("\nMINDMATCH — BACKWARD CHAINING\n" + "=" * 34)
    print("Goal: Is game_complete true? Start with the goal and look for evidence.")
    proven = backward_chain("game_complete", {"eight_pairs_matched"}, RULES)
    print("\nConclusion:", proven)
    print("\nTry a case where the player has found only one pair:")
    print("Goal: Is game_complete true?")
    proven = backward_chain("game_complete", {"at_least_one_pair_matched"}, RULES)
    print("Conclusion:", proven)

if __name__ == "__main__":
    main()
